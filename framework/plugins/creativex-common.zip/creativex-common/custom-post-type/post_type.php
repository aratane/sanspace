<?php
// register post type team
add_action( 'init', 'register_creativex_team' );
function register_creativex_team() {
    $labels = array( 
        'name' => __( 'All Team', 'creativex' ),
        'singular_name' => __( 'All Team', 'creativex' ),
        'add_new' => __( 'Add New Team', 'creativex' ),
        'add_new_item' => __( 'Add New Team', 'creativex' ),
        'edit_item' => __( 'Edit Team', 'creativex' ),
        'new_item' => __( 'New Team', 'creativex' ),
        'view_item' => __( 'View Team', 'creativex' ),
        'search_items' => __( 'Search Team', 'creativex' ),
        'not_found' => __( 'No Team found', 'creativex' ),
        'not_found_in_trash' => __( 'No Team found in Trash', 'creativex' ),
        'parent_item_colon' => __( 'Parent Team:', 'creativex' ),
        'menu_name' => __( 'Team', 'creativex' ),
    );
    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Team',
        'supports' => array( 'title', 'authors','editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'team', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-embed-post', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );
    register_post_type( 'team', $args );
}
add_action( 'init', 'create_type_hierarchical_taxonomy', 0 );
//create a custom taxonomy name it Skillss for your posts
function create_type_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
  $labels = array(
    'name' => __( 'Type', 'creativex' ),
    'singular_name' => __( 'type', 'creativex' ),
    'search_items' =>  __( 'Search type','creativex' ),
    'all_items' => __( 'All type','creativex' ),
    'parent_item' => __( 'Parent type','creativex' ),
    'parent_item_colon' => __( 'Parent type:','creativex' ),
    'edit_item' => __( 'Edit type','creativex' ), 
    'update_item' => __( 'Update type','creativex' ),
    'add_new_item' => __( 'Add New type','creativex' ),
    'new_item_name' => __( 'New type Name','creativex' ),
    'menu_name' => __( 'type','creativex' ),
  );     
// Now register the taxonomy
  register_taxonomy('type',array('team'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));
}