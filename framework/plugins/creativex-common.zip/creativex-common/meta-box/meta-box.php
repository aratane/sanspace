<?php
/**
 * Plugin Name: Meta Box
 * Plugin URI:  https://metabox.io
 * Description: Create custom meta boxes and custom fields in WordPress.
 * Version:     5.3.3
 * Author:      MetaBox.io
 * Author URI:  https://metabox.io
 * License:     GPL2+
 * Text Domain: meta-box
 * Domain Path: /languages/
 * 
 * @package Meta Box
 */

if ( defined( 'ABSPATH' ) && ! defined( 'RWMB_VER' ) ) {
    register_activation_hook( __FILE__, 'rwmb_check_php_version' );

    /**
     * Display notice for old PHP version.
     */
    function rwmb_check_php_version() {
        if ( version_compare( phpversion(), '5.3', '<' ) ) {
            die( esc_html__( 'Meta Box requires PHP version 5.3+. Please contact your host to upgrade.', 'meta-box' ) );
        }
    }




    require_once dirname( __FILE__ ) . '/inc/loader.php';
    $rwmb_loader = new RWMB_Loader();
    $rwmb_loader->init();


    add_filter( 'rwmb_meta_boxes', function ( $meta_boxes ) {

    $prefix = '_cmb_';


    //Add other metaboxs as needed

    


  // Open Code


    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Post Container',
                'desc' => 'Show in post page',
                'default' => '',
                'id' => $prefix . 'post_container',
                'type' => 'wysiwyg'
            ),
            array(
                'name' => 'Post Blog Owl',
                'desc' => 'Show in post page',
                'default' => '',
                'id' => $prefix . 'blog_owl',
                'type' => 'wysiwyg'
            ),
            array(
                'name' => 'Summary Post Home Page',
                'desc' => 'Show in home page',
                'default' => '',
                'id' => $prefix . 'post_summary',
                'type' => 'wysiwyg'
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'team_setting',
        'title'      => 'Team Setting',
        'pages'      => array('team'), // Team type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Link Twitter :',
                'desc' => 'Show in index page',
                'default' => '#',
                'id' => $prefix . 'link_twitter',
                'type' => 'text'
            ),
            array(
                'name' => 'Link Facebook :',
                'desc' => 'Show in index page',
                'default' => '#',
                'id' => $prefix . 'link_facebook',
                'type' => 'text'
            ),
            array(
                'name' => 'Link Instagram :',
                'desc' => 'Show in index page',
                'default' => '#',
                'id' => $prefix . 'link_instagram',
                'type' => 'text'
            ),
        )
    );

// End Code
    return $meta_boxes;
});
}